import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login';
import { RegistroComponent } from './pages/registro/registro';
import { LugaresComponent } from './pages/lugares/lugares';
import { DetalleLugarComponent } from './pages/detalle-lugar/detalle-lugar';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'registro',
    component: RegistroComponent
  },
  {
    path: 'lugares',
    component: LugaresComponent
  },
  {
    path: 'lugar/:id',
    component: DetalleLugarComponent
  }
];