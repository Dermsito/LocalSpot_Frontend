import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {
  credenciales = {
    correo: '',
    password: ''
  };

  constructor(private router: Router) {}

  onLogin(): void {
    console.log('Iniciando sesión con:', this.credenciales);
    this.router.navigate(['/lugares']);
  }
}