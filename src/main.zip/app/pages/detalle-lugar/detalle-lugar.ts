import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detalle-lugar',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './detalle-lugar.html',
  styleUrl: './detalle-lugar.css'
})
export class DetalleLugarComponent implements OnInit {
  // Base de datos local de prueba para los 6 lugares
  baseDeDatosLugares = [
    {
      id: 1,
      nombre: 'Restaurante El Mirador',
      categoria: 'Restaurantes',
      direccion: 'Calle 10 # 5-20',
      horario: 'Lunes a Domingo: 12:00 PM - 10:00 PM',
      calificacionPromedio: 4.8,
      icono: '🍽️',
      descripcion: 'Disfruta de platos gastronómicos de alta calidad con la mejor vista panorámica de la ciudad.',
      esFavorito: false,
      etiquetas: ['Vista Panorámica', 'Comida Gourmet', 'Reservas', 'Parqueadero'],
      calificaciones: [
        { usuario: 'Mateo R.', estrellas: 5, fecha: 'Hace 1 día', comentario: 'La comida es increíble y la vista al atardecer no tiene precio.' }
      ]
    },
    {
      id: 2,
      nombre: 'Café Central',
      categoria: 'Cafeterías & Postres',
      direccion: 'Carrera 7 # 12-40',
      horario: 'Lunes a Sábado: 08:00 AM - 08:00 PM',
      calificacionPromedio: 4.5,
      icono: '☕',
      descripcion: 'Un espacio moderno y acogedor diseñado para amantes del buen café, postres artesanales y reuniones de trabajo.',
      esFavorito: false,
      etiquetas: ['Wi-Fi Gratis', 'Pet Friendly', 'Aire Acondicionado', 'Espacio Trabajo'],
      calificaciones: [
        { usuario: 'Carlos M.', estrellas: 5, fecha: 'Hace 2 días', comentario: '¡El mejor café de especialidad de la zona!' },
        { usuario: 'Ana P.', estrellas: 4, fecha: 'Hace 1 semana', comentario: 'Ambiente súper tranquilo para trabajar.' }
      ]
    },
    {
      id: 3,
      nombre: 'Bar La Estación',
      categoria: 'Bares & Vida Nocturna',
      direccion: 'Calle 15 # 8-30',
      horario: 'Jueves a Sábado: 06:00 PM - 02:00 AM',
      calificacionPromedio: 4.2,
      icono: '🍸',
      descripcion: 'El lugar ideal para disfrutar de coctelería de autor, música en vivo y un ambiente nocturno vibrante.',
      esFavorito: false,
      etiquetas: ['Música en Vivo', 'Cocteles', 'Zona de Baile', 'Promociones'],
      calificaciones: [
        { usuario: 'Sofia T.', estrellas: 4, fecha: 'Hace 3 días', comentario: 'Excelentes tragos y muy buen ambiente los fines de semana.' }
      ]
    },
    {
      id: 4,
      nombre: 'Cine Olimpo',
      categoria: 'Entretenimiento',
      direccion: 'Av. Principal # 45-10',
      horario: 'Lunes a Domingo: 01:00 PM - 11:00 PM',
      calificacionPromedio: 4.6,
      icono: '🎬',
      descripcion: 'Salas de cine tradicionales y 3D con tecnología de audio envolvente y la mejor confitería.',
      esFavorito: false,
      etiquetas: ['Salas 3D', 'Confitería Premium', 'Estrenos', 'Acceso Discapacitados'],
      calificaciones: [
        { usuario: 'David L.', estrellas: 5, fecha: 'Hace 5 días', comentario: 'Las sillas son ultra cómodas y el sonido es espectacular.' }
      ]
    },
    {
      id: 5,
      nombre: 'Gimnasio Fitness Club',
      categoria: 'Deportes & Fitness',
      direccion: 'Calle 20 # 14-05',
      horario: 'Lunes a Viernes: 05:00 AM - 10:00 PM',
      calificacionPromedio: 4.7,
      icono: '⚽',
      descripcion: 'Centro deportivo equipado con máquinas de última generación, clases grupales y entrenadores personalizados.',
      esFavorito: false,
      etiquetas: ['Máquinas Modernas', 'Clases de Spin', 'Entrenadores', 'Duchas'],
      calificaciones: [
        { usuario: 'Laura G.', estrellas: 5, fecha: 'Hace 4 días', comentario: 'Instalaciones impecables y ambiente muy motivador.' }
      ]
    },
    {
      id: 6,
      nombre: 'Plaza Comercial Centro',
      categoria: 'Tiendas & Compras',
      direccion: 'Carrera 10 # 10-10',
      horario: 'Lunes a Domingo: 09:00 AM - 09:00 PM',
      calificacionPromedio: 4.4,
      icono: '🛍️',
      descripcion: 'Centro comercial con gran variedad de tiendas de ropa, tecnología, plazoleta de comidas y parqueadero vigilado.',
      esFavorito: false,
      etiquetas: ['Zona Comercial', 'Plazoleta de Comidas', 'Parqueadero', 'Cajeros Automaticos'],
      calificaciones: [
        { usuario: 'Andrés V.', estrellas: 4, fecha: 'Hace 1 semana', comentario: 'Encuentras de todo un poco y tiene buen parqueadero.' }
      ]
    }
  ];

  lugar: any;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    // Obtiene el ID desde la URL (/lugar/:id)
    const idParam = Number(this.route.snapshot.paramMap.get('id'));
    const encontrado = this.baseDeDatosLugares.find(l => l.id === idParam);
    
    // Si lo encuentra carga ese lugar, si no, carga el primero por defecto
    this.lugar = encontrado ? encontrado : this.baseDeDatosLugares[0];
  }

  toggleFavorito(): void {
    this.lugar.esFavorito = !this.lugar.esFavorito;
  }
}